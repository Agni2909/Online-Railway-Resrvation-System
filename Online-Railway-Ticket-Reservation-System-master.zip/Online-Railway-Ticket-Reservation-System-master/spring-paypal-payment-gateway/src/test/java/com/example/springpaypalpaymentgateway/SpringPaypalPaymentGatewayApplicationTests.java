package com.example.springpaypalpaymentgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPaypalPaymentGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
