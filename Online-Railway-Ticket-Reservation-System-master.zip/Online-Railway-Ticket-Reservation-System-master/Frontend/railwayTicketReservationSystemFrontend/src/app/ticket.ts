export class Ticket {
  constructor(
    pnrNo: Number,
    trainName: String,
    passengerName: string,
    passengerPhNo: string,
    passengerEmail: string,
    source: String,
    destination: String,
    noOfTicket: number,
    totalPrice: number
  ) {}
}
