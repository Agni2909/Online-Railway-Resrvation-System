export class Login{
    constructor(
        username:string,
        password:string
    ){}
}