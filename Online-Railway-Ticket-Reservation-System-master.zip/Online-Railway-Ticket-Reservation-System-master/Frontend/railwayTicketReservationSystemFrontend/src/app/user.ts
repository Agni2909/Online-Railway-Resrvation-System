export class User{
    constructor(
        userName:string,
        userEmail:string,
        userPassword:string,
        userPhoneNo:string
    ){}
}