export class TicketDetails {
  constructor(
    passengerName: string,
    passengerPhNo: string,
    passengerEmail: string,
    noOfTickets: number
  ) {}
}
