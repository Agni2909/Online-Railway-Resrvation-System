export class Train {
  constructor(
    trainName: string,
    fromStation: string,
    toStation: string,
    ticketFare: number,
    date: string,
    time: string
  ) {}
}
