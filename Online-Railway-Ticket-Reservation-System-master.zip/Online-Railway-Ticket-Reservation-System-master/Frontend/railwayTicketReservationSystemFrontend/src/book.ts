export class book{
    constructor(
        passengerName:string,
        passengerPhNo:string,
        passengerEmail:string,
        noOfTicket:number,
    ){}
}